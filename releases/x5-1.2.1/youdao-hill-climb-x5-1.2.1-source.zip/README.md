# Youdao Hill Climb

A landscape hill-climb game for the Falcon/QuickJS mini-app runtime at an 800x254 logical resolution.

## Version 1.2.1

### About dialog and temporary backdoor

- A small `!` button appears in a safe corner of the ready, garage, and game-over interfaces.
- It opens an in-app About dialog describing the project and crediting **GuZhuooo**.
- Tapping `GuZhuooo` five times within the rolling tap window adds `10000000` garage coins.
- The reward is intentionally repeatable as a temporary development backdoor and is saved immediately.

### Progress storage migration

- The progress namespace is now:
  `/userdata/miniapp/hill_climb_ridge/progress.json`
- The user-provided `/userdate` spelling was corrected to the directory that actually exists on firmware 3.4.6: `/userdata`.
- On first launch, version 1.2.1 reads the new namespace first. If it is absent, it reads legacy key `hill_climb_progress_v7`, writes the same data to the new namespace, and continues from it.
- Important runtime detail: firmware 3.4.6 does not provide QuickJS `std` or `os`, and its public Falcon API exposes storage but no file API. Therefore this path is the app's Falcon storage namespace; Falcon still controls the physical backing file. A real JSON file at that absolute Linux path requires a matching native JSAPI plugin/toolchain.

### Existing content

- Four maps: 青草山谷、赤岩风口、月尘环坑、冰原极光。
- Four vehicles: 山脊吉普、弹跳甲虫、六轮月车、蒸汽矿龙。
- Garage selection, unlocks, upgrades, map/vehicle tuning, and the existing natural airborne/contact physics remain unchanged.

## Controls

- Hold the right button for throttle and forward pitch while airborne.
- Hold the left button for brake/reverse and backward pitch while airborne.
- Use the top-right HUD button to pause/continue during a run.
- Use the small `!` on menu screens to open About.

## Target device

- SoC/architecture: cv182x / ARMv7
- Firmware: 3.4.6, built 2026-03-30
- C library: glibc 2.23
- App ID: `8001799000000002`
- Start page: `index`
- Device profile: `profiles/youdao-cv182x-3.4.6.yaml`

## Build

```powershell
& 'F:\js\node.exe' `
  'C:\Users\Ianhi\AppData\Local\node\corepack\v1\pnpm\10.12.4\bin\pnpm.cjs' `
  -C ui package
```

Build artifact: `ui/8001799000000002.1_2_1.amr`

Release copy: `dist/youdao-hill-climb-1.2.1-cv182x.amr`

## Install and start

```powershell
$adb = 'F:\mytool\platform\platform-tools\adb.exe'
& $adb push '.\ui\8001799000000002.1_2_1.amr' '/tmp/hill-climb-1.2.1.amr'
& $adb shell '/usr/bin/miniapp_cli install /tmp/hill-climb-1.2.1.amr'
& $adb shell '/usr/bin/miniapp_cli start 8001799000000002 index'
```

Firmware 3.4.6 requires positional page argument `index`.

## Verification evidence

- `test/progress-storage-smoke.mjs`: new namespace, legacy migration, empty state, and 8-digit coin serialization.
- Physics smoke/difficulty tests and all 16 map/vehicle combinations remain passing.
- Real device: `!` layout, About copy, author credit, five taps, reward feedback, `10000000` wallet, and persistence after switching away/back were verified on August 24, 2026.
- Screenshots: `device-capture-1.2.1-ready.png`, `device-capture-1.2.1-about.png`, `device-capture-1.2.1-reward.png`, `device-capture-1.2.1-coins.png`, `device-capture-1.2.1-persist.png`.
- Final AMR size: 23958 bytes.
- Final AMR SHA-256: $hash.
