import { BasePage } from './base-page.js';

const PROFILE = {
  logicalWidth: 800,
  logicalHeight: 254,
  physicalWidth: 254,
  physicalHeight: 800,
  direction: 270
};

class App extends $falcon.App {
  onLaunch(options) {
    super.onLaunch(options);
    this.setViewPort(PROFILE.logicalWidth);
    this.screenInfo = {
      renderWidth: PROFILE.logicalWidth,
      renderHeight: PROFILE.logicalHeight,
      direction: PROFILE.direction
    };
    $falcon.useDefaultBasePageClass(BasePage);
    console.log('[device-profile] cv182x armv7 glibc2.23 logical=' + PROFILE.logicalWidth + 'x' + PROFILE.logicalHeight + ' physical=' + PROFILE.physicalWidth + 'x' + PROFILE.physicalHeight + ' direction=' + PROFILE.direction);
  }

  onShow() { super.onShow(); }
  onHide() { super.onHide(); }
  onDestroy() { super.onDestroy(); }
}

export default App;
